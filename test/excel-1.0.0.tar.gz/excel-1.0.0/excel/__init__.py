# shortcuts for import 
# usage: from excel import OpenExcel
from .xlrd_shortcuts import OpenExcel
